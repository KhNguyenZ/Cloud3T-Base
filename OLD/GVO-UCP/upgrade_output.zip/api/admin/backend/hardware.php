<?php
include_once "../../../modules/config.php";
if(isset($_GET['action']))
{
    // $KNCMS->msg_success($_GET['action'],"", 3000);
    if($_GET['action'] == "delete")
    {
        if(isset($_GET['hardware']))
        {
            $action = $_GET['action'];
            $hwi = $_GET['hardware'];

            if($action == "delete")
            {
                $KNCMS->query("DELETE FROM `hardwareid` WHERE `HardwareID` = '$hwi'");

                $KNCMS->msg_success("Đã xóa Hardwareid:". $hwi. "thành công", $api_admin_ur."page/hardware.php", 3000);
            }
        }
    }
    if($_GET['action'] == "banned")
    {
        if(isset($_GET['hardware']))
        {
            $action = $_GET['action'];
            $hwi = $_GET['hardware'];

            if($action == "banned")
            {
                $KNCMS->query("UPDATE `hardwareid` SET `Status` = '-1' WHERE `HardwareID` = '$hwi'");

                $KNCMS->msg_success("Đã banned Hardwareid:". $hwi. "thành công", $api_admin_ur."page/hardware.php", 3000);
            }
        }
    }

    if($_GET['action'] == "cleodelete")
    {
        if(isset($_GET['hashcode']))
        {
            $action = $_GET['action'];
            $hashcode = $_GET['hashcode'];

            if($action == "cleodelete")
            {
                $KNCMS->query("DELETE FROM `cleo` WHERE `HashFile` = '$hashcode'");

                $KNCMS->msg_success("Đã delete cleo thành công", $api_admin_ur."page/cleo.php", 3000);
            }
        }
    }
}