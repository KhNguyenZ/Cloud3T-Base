

<?php
include "../private/head.php";
include_once "../../../modules/config.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $file_name = $_FILES["fileToUpload"]["name"];
    $file_tmp = $_FILES["fileToUpload"]["tmp_name"];

    $md5_hash = md5_file($file_tmp);


    $upload = $KNCMS->query("INSERT INTO `cleo` SET `Name` = '$file_name', `HashFile` = '$md5_hash', `UploadTime` = '$time'");
    die('<script>setTimeout(function(){ location.href = "' . $api_admin_ur . "page/cleo.php" . '" },' . 1000 . ');</script>');
}
?>