<?php include_once "../../modules/config.php"; ?>
<?php require_once('private/head.php') ?>
<?php require_once('private/nav.php') ?>
<title>Admin Panel</title>
<section class="content">

    <div class="container-fluid">
        <div class="row">
            
        </div>
    </div>
</section>

<?php require_once('private/foot.php') ?>