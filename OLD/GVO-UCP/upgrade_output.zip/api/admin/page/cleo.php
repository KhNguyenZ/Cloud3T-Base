<?php include_once $_SERVER['DOCUMENT_ROOT']."/modules/config.php"; ?>
<?php require_once('../private/head.php') ?>
<?php require_once('../private/nav.php') ?>
<title>Member Panel</title>

<section class="col-lg-12 connectedSortable">
    <div class="card card-primary card-outline">
        <div class="card-header ">
            <h3 class="card-title">
                <i class="fas fa-history mr-1"></i>
                NHẬT KÝ HOẠT ĐỘNG
            </h3>
            <div class="card-tools">
                <button type="button" class="btn bg-success btn-sm" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                </button>
                <button type="button" class="btn bg-warning btn-sm" data-card-widget="maximize"><i class="fas fa-expand"></i>
                </button>
                <button type="button" class="btn bg-danger btn-sm" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                </button>
                <center>
                    <form action="../backend/upload.php" method="post" enctype="multipart/form-data">
                        <input type="file" name="fileToUpload" id="fileToUpload" />
                        <input type="submit" value="Upload" />
                    </form>
                </center>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive p-0">
                <table id="datatable2" class="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th width="5%">ID</th>
                            <th>HardwareID</th>
                            <th width="40%">Status</th>
                            <th>Update Time</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        foreach ($KNCMS->get_list("SELECT * FROM `cleo` ORDER BY id desc") as $row) {
                        ?>
                            <tr>
                                <td><?= $i ?></td>
                                <td><?= $row['Name'] ?></a>
                                </td>
                                <td><?= $row['HashFile'] ?></td>
                                <td><?= $row['UploadTime'] ?></td>
                                <td>
                                    <a class="btn btn-app" href="?action=cleodelete&hashcode=<?= $row['HashFile'] ?>">
                                        <i class="fas fa-edit"></i> Delete
                                    </a>
                                    <?php $i++ ?>
                                </td>
                                <?php require_once('../backend/hardware.php'); ?>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php require_once('../private/foot.php') ?>